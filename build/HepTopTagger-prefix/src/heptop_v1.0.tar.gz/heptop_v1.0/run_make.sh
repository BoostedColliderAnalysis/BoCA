#!/sh

runmake(){
  make TARGET=$1
}

runmake example_toptagger
